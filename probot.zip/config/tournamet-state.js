// tournament is registering bots,
    const registration = 'registration';

// tournament is active,
   const active = 'active';

// tournament is over,
    const closed = 'closed';


module.exports = {
    registration,
    active,
    closed
};
