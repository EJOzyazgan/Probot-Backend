
exports = module.exports = {

  bet: function (gamestate) {

    'use strict';

    // console.log(`Hello my name is ${gamestate.players[gamestate.me].name}!`);
    console.log(gamestate);

    return 0;

  }

};
